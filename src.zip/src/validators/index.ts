import { z } from "zod";

// ── Stats ──────────────────────────────────────────────────────────────────
export const GetStatsSummaryResponse = z.object({
  registeredMembers: z.number(),
  wardsCovered: z.number(),
  pilotProjectWomen: z.number(),
  commitmentPercent: z.number(),
});

// ── Membership ─────────────────────────────────────────────────────────────
export const CreateMembershipApplicationBody = z.object({
  fullName: z.string().min(1),
  gender: z.string().min(1),
  phone: z.string().min(1),
  email: z.string().email(),
  state: z.string().min(1),
  lga: z.string().min(1),
  ward: z.string().min(1),
  occupation: z.string().min(1),
});

export const CreateMembershipApplicationResponse = z.object({
  id: z.number(),
  membershipNumber: z.string(),
  fullName: z.string(),
  gender: z.string(),
  phone: z.string(),
  email: z.string(),
  state: z.string(),
  lga: z.string(),
  ward: z.string(),
  occupation: z.string(),
  status: z.string(),
  createdAt: z.coerce.date(),
});

export const LookupMembershipQueryParams = z.object({
  membershipNumber: z.string().min(1),
});

export const LookupMembershipResponse = CreateMembershipApplicationResponse;

// ── Volunteers ─────────────────────────────────────────────────────────────
export const CreateVolunteerApplicationBody = z.object({
  fullName: z.string().min(1),
  phone: z.string().min(1),
  email: z.string().email(),
  skills: z.string().min(1),
  experience: z.string().optional(),
  availability: z.string().min(1),
});

export const CreateVolunteerApplicationResponse = z.object({
  id: z.number(),
  fullName: z.string(),
  phone: z.string(),
  email: z.string(),
  skills: z.string(),
  experience: z.string().nullish(),
  availability: z.string(),
  status: z.string(),
  createdAt: z.coerce.date(),
});

// ── Contact ────────────────────────────────────────────────────────────────
export const CreateContactMessageBody = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  phone: z.string().optional(),
  subject: z.string().min(1),
  message: z.string().min(1),
});

export const CreateContactMessageResponse = z.object({
  id: z.number(),
  name: z.string(),
  email: z.string(),
  phone: z.string().nullish(),
  subject: z.string(),
  message: z.string(),
  createdAt: z.coerce.date(),
});

// ── Newsletter ─────────────────────────────────────────────────────────────
export const CreateNewsletterSubscriptionBody = z.object({
  email: z.string().email(),
});

export const CreateNewsletterSubscriptionResponse = z.object({
  id: z.number(),
  email: z.string(),
  createdAt: z.coerce.date(),
});
